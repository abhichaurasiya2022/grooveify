#!/bin/sh
source .venv/bin/activate
python -m flask --app main run --debug --port 5001