from flask import Flask, render_template, request, redirect, url_for, session, flash, send_file, make_response
from pymongo import MongoClient
import io
from bson.objectid import ObjectId
import pytesseract
import base64
from PIL import Image
import os
from transformers import pipeline, AutoTokenizer, AutoModelForSeq2SeqLM
from pytesseract import TesseractError

from bcrypt import hashpw, checkpw, gensalt 

app = Flask(__name__)

# MongoDB setup
client = MongoClient('mongodb+srv://abhichaurasiya2022:ReWxXViDO1kNvOta@susterms.n9cogi6.mongodb.net/?retryWrites=true&w=majority&appName=SusTerms', tls=True)
db = client['tos_app']

#set the key
app.secret_key = 'your_secret_key'

users_collection = db['users']
analysis_history_collection = db['analysis_history']

@app.route("/", methods=['GET', 'POST'])
def index():
    if 'username' in session:
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        print(request.files)  # This line remains for debugging purposes
    return render_template('index.html')

@app.route('/dashboard', methods=['GET', 'POST'])
def dashboard():
    if 'username' in session:
        history_id = request.args.get('history_id')
        
        # Retrieve user's analysis history
        user_history = list(analysis_history_collection.find({'username': session['username']}).sort('timestamp', -1).limit(10))
        
        if history_id:
            # Load from history
            history_entry = analysis_history_collection.find_one({"_id": ObjectId(history_id)})           
            if history_entry:
                input_text=history_entry["input_text"]
                summary = history_entry["summary"]
                risks=history_entry["risks"]
                return render_template("dashboard.html", username=session["username"], summary=summary, risks=risks, input_text=input_text, history=user_history)
        
        if request.method == 'POST':
            
            text = None
            filepath = None
            filename = None
            file_content = None
            if 'file' in request.files:
                
                file = request.files['file']
                if file.filename:
                    filepath = os.path.join('uploads', file.filename)
                    file.save(filepath)
                    
            if 'text' in request.form:
                text = request.form['text']
                
            if text:  # Prioritize text input
               summary = summarize_text(text)
               risks = highlight_risks(summary)
               
            elif filepath:
              if filepath.lower().endswith((".png", ".jpg", ".jpeg", ".tiff", ".bmp", ".gif")):
                    try:
                        text = ocr_text(filepath)            
                    except TesseractError as e:
                            return render_template('error.html', error="Tesseract OCR failed. Ensure Tesseract is installed and properly configured. Error details: " + str(e))
                    except FileNotFoundError:
                        return render_template('error.html', error=f"Image file not found at path: {filepath}")
                    except Exception as e:
                        return render_template('error.html', error=str(e))
              else:                        
                try:
                    with open(filepath, 'r') as f:
                        filename = file.filename
                        file_content = f.read()
                        file_content_base64 = base64.b64encode(file_content.encode('utf-8')).decode('utf-8')
                        text = file_content
                except (UnicodeDecodeError, FileNotFoundError) as e:
                    return render_template("error.html", error=str(e))
                
                summary = summarize_text(text) if text else "No text to process."
            
                risks = highlight_risks(summary) if summary else []
            
            else:
              summary = "No text to process."
              risks = []
            
            # Save analysis history to the database
            analysis_data = {
                "username": session["username"],
                "timestamp": datetime.datetime.now(),
                "filename": filename,
                "file_content": file_content,
                "input_text": text,  # Store the input text
                "summary": summary,
                "risks": risks,
            }
            analysis_history_collection.insert_one(analysis_data)
            return render_template('dashboard.html', username=session['username'], summary=summary, risks=risks, input_text=text, history=user_history)            
        # Retrieve user's analysis history
        user_history = list(analysis_history_collection.find({'username': session['username']}).sort('timestamp', -1).limit(10))

        # Pass the history to the template
        return render_template('dashboard.html', username=session['username'], summary=None, risks=None, history = user_history)
    
    
    return redirect(url_for('login'))

@app.route('/download_file/<history_id>')
def download_file(history_id):
    """
    Downloads the file associated with a given history entry.
    """
    history_entry = analysis_history_collection.find_one({'_id': ObjectId(history_id)})
    if not history_entry or 'file_content' not in history_entry or 'filename' not in history_entry:
        flash('File not found.', 'error')
        return redirect(url_for('dashboard'))
    
    file_content = history_entry['file_content']
    filename = history_entry['filename']
    
    # Re-encode as UTF-8 before base64 decoding
    decoded_file_content = base64.b64decode(file_content.encode('utf-8'))
    return send_file(io.BytesIO(decoded_file_content), download_name=filename, as_attachment=True)    

@app.route('/register', methods=['GET', 'POST'])

def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Check if the username already exists
        if users_collection.find_one({'username': username}):
            flash('Username already exists. Please choose a different one.')
            return render_template('register.html')

        # Hash the password
        hashed_password = hashpw(password.encode('utf-8'), gensalt())

        # Insert the new user into the database
        users_collection.insert_one({'username': username, 'password': hashed_password})
        flash('Registration successful. Please log in.')
        return redirect(url_for('login'))  # Assuming you have a login route
    
    
    return render_template('register.html')        

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = users_collection.find_one({'username': username})
        if user and checkpw(password.encode('utf-8'), user['password']):
            session['username'] = username
            flash('Login successful.', 'success')
            return redirect(url_for('dashboard'))  # Redirect to dashboard after login
        else:
            flash('Invalid username or password.', 'error')

    return render_template('login.html')
    

import datetime
@app.route('/logout')

def logout():
    session.clear()
    flash("You have been logged out", 'success')
    return render_template('login.html')



@app.route("/process")
def process():
    filepath = request.args.get('filepath')
    text = request.args.get('text')

    if text:
       summary = summarize_text(text)
       risks = highlight_risks(summary)
    elif filepath:        
        
        if filepath.lower().endswith((".png", ".jpg", ".jpeg", ".tiff", ".bmp", ".gif")):
            try:
                text = ocr_text(filepath)            
            except TesseractError as e:
                    return render_template('error.html', error="Tesseract OCR failed. Ensure Tesseract is installed and properly configured. Error details: " + str(e))
            except FileNotFoundError:
                return render_template('error.html', error=f"Image file not found at path: {filepath}")
            except Exception as e:
                return render_template('error.html', error=str(e))
        else:
            try:
                with open(filepath, "r") as f:
                    text = f.read()
            except (UnicodeDecodeError, FileNotFoundError) as e:
                return render_template("error.html", error=str(e))
        summary = summarize_text(text) if text else "No text to process."
      
      
        risks = highlight_risks(text) if text else []
    else:
      summary = "No text to process."
      risks = []
    
    return render_template("results.html", summary=summary, risks=risks)


@app.route("/results")
def results():
    # This route might not be needed now, as results are displayed directly from /process
    return redirect(url_for("index"))


# Placeholder functions - replace with actual logic
def ocr_text(image_path):
    img = Image.open(image_path)
    text = pytesseract.image_to_string(img)
    return text


summarizer = None


def summarize_text(text):
    # Replace this with your actual Gemini API key
    gemini_api_key = "AIzaSyBBK4ol_kqH1hJ_lJLH4Jrrv3JJaCZjS70"

    # Initialize the Gemini API client (replace with actual initialization)
    import google.generativeai as genai

    genai.configure(api_key=gemini_api_key)
    model = genai.GenerativeModel("gemini-2.0-flash")  # Or the appropriate model name

    try:
        # Adjust the prompt as needed for Gemini
        response = model.generate_content(f"Summarize the following text: {text}")
        summary = response.text
        return summary
    except Exception as e:
        print(f"Error during summarization: {e}")
        return "Error summarizing text."


def highlight_risks(text):
    """
    Highlights risky sentences in a text and assigns a threat level based on keyword count.
    Returns a list of dictionaries, each with 'sentence' and 'threat_level' keys.
    """
    risk_keywords = [
        "liability",
        "terminate",
        "binding",
        "waive",
        "disclaimer",
        "warranty",
        "limitation",
        "arbitration",
        "indemnify",
        "legal"
    ]
    sentences = [s.strip() for s in text.split(".") if s.strip()]
    risks = []

    for sentence in sentences:
        keywords_found = [keyword for keyword in risk_keywords if keyword in sentence.lower()]
        keyword_count = len(keywords_found)

        if keyword_count > 0:
            if keyword_count <= 2:
                threat_level = "🔵 Minimal"
            elif keyword_count <= 5:
                threat_level = "🟡 Caution"
            else:
                threat_level = "🔴 High Risk"

            risks.append({
                "sentence": sentence,
                "threat_level": threat_level
            })

    return risks


if __name__ == "__main__":
    if not os.path.exists("uploads"):
       os.makedirs("uploads")
    app.run(debug=True)

