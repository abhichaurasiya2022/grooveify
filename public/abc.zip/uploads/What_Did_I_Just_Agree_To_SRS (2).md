# Software Requirements Specification (SRS)

## 1. Introduction

### 1.1 Purpose
This document defines the software requirements for the **"What Did I Just Agree To?" Button**, a browser extension and Flask-based web application that captures Terms of Service (ToS), EULAs, or pop-ups, processes the text using OCR and NLP, and returns simplified summaries with visual threat indicators.

### 1.2 Scope
The system will allow users to:
- Capture ToS or pop-up text via browser or screenshot upload.
- Summarize legalese into easy-to-read explanations.
- Highlight high-risk clauses (e.g., biometric sharing, subscription traps).
- Assign a threat level indicator (e.g., 🔵 Minimal, 🟡 Caution, 🔴 High Risk).

It will consist of:
- Flask backend API for OCR, AI summarization, and risk detection.
- Browser extension or upload-based front-end for users.
- Admin dashboard for updating risk-detection rules and AI training data.

## 2. Overall Description

### 2.1 User Needs
- Users often click “I agree” without reading ToS.
- The app addresses this by summarizing long documents and flagging key risks.

### 2.2 Assumptions & Dependencies
- Users have a browser that supports extensions.
- OCR will use Tesseract or a similar engine.
- NLP will rely on GPT-based or HuggingFace summarizers.
- Risk detection uses predefined keywords + AI classification.

## 3. System Features and Requirements

### 3.1 Functional Requirements

#### FR-1: Upload or Capture Legal Text
- Users can upload a screenshot or copy/paste text.
- Extension can capture text from a focused browser window.

#### FR-2: OCR Processing
- Flask uses Tesseract to convert images to text.
- Clean and format raw text before analysis.

#### FR-3: Summarization Engine
- Text is summarized using GPT or HuggingFace models.
- Option for short or detailed summary.

#### FR-4: Risk Detector
- Keyword pattern matcher highlights red flags (e.g., “data sharing”, “biometric”).
- NLP model assigns a threat score: Safe, Moderate, Risky.

#### FR-5: Threat Indicator
- Summaries are visually tagged:
  - 🔵 Minimal
  - 🟡 Caution
  - 🔴 High Risk

#### FR-6: Browser Extension Integration
- Capture visible ToS or EULA from the current page.
- Send it to the Flask API for processing.

#### FR-7: Result Display
- Summary, highlights, and risk indicator shown in browser popup or web dashboard.

#### FR-8: User History (Optional)
- Logged-in users can view previous summaries.
- Data stored encrypted.

### 3.2 Non-Functional Requirements

| Requirement    | Description                                                  |
|----------------|--------------------------------------------------------------|
| Performance     | Response time < 5 sec for summary on average document size. |
| Scalability     | Can handle 100+ concurrent users.                           |
| Security        | HTTPS, input sanitization, and document privacy.            |
| Usability       | Clear UI with emphasis on readability and risk clarity.     |
| Portability     | Works with Chrome, Firefox; Mobile support later.           |

## 4. System Architecture

### 4.1 Components
- **Frontend**:
  - Browser Extension (JS/HTML)
  - Upload Web App (React/HTML UI)

- **Backend (Flask)**:
  - `/ocr` — OCR endpoint
  - `/summarize` — Summarization endpoint
  - `/analyze` — Risk detection and threat scoring
  - `/history` — (Optional) User history

### 4.2 External APIs & Tools
- **OCR**: Tesseract via Python wrapper
- **Summarization**: GPT (OpenAI API) or HuggingFace
- **Storage**: PostgreSQL or MongoDB for logs/history
- **Authentication**: OAuth (Google login optional)

## 5. UI Mockup Overview

**Browser Popup**:
- 📄 Summary in 3-5 bullet points
- 🛑 High-risk clauses highlighted
- 🔴🟡🔵 Threat level icon
- 🔁 “Rescan” / “Read Full Version” link

## 6. Future Enhancements

- Chrome + Firefox support for full page scraping
- PDF uploads
- Language detection & translation
- Dark mode
- Crowd-sourced flagging of shady clauses
- API for developers

## 7. Appendix

### Risk Keyword Samples:
- “We may share your biometric data…”
- “Your subscription will auto-renew…”
- “We retain the right to access your files…”

### Threat Score Formula:
- Based on # of risky keywords, sentence sentiment, clause placement, and GDPR flag compliance.